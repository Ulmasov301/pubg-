# PUBG Bot (Nazarbek Edition)

🎮 Bu Telegram bot faqat PUBG akkauntlarni tarqatadi.

## Ishlash tartibi
- Foydalanuvchi `🎮 PUBG akkaunt olish` tugmasini bosadi
- Admin esa akkaunt qo‘shadi va statistikani ko‘radi

## Ishga tushirish

```bash
pip install -r requirements.txt
python pubg_bot.py
```

.env faylga quyidagilarni yozing:

```
TOKEN=YOUR_BOT_TOKEN
ADMIN_ID=YOUR_TELEGRAM_ID
```
