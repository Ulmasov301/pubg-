import telebot
import os
from telebot.types import ReplyKeyboardMarkup
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID"))

bot = telebot.TeleBot(TOKEN)
ACCOUNTS_FILE = "accounts/pubg.txt"

def get_pubg_account():
    if os.path.exists(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, "r") as f:
            lines = f.readlines()
        if lines:
            acc = lines[0].strip()
            with open(ACCOUNTS_FILE, "w") as f:
                f.writelines(lines[1:])
            return acc
    return None

def add_pubg_account(account):
    with open(ACCOUNTS_FILE, "a") as f:
        f.write(account + "\n")

@bot.message_handler(commands=['start'])
def start(message):
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("🎮 PUBG akkaunt olish")
    if message.from_user.id == ADMIN_ID:
        markup.add("➕ PUBG akkaunt qo‘shish", "📄 Qolganlar")
    bot.send_message(message.chat.id, "🤖 Xush kelibsiz! Men PUBG akkaunt tarqatuvchi botman.", reply_markup=markup)

@bot.message_handler(func=lambda message: True)
def handle_message(message):
    if message.text == "🎮 PUBG akkaunt olish":
        acc = get_pubg_account()
        if acc:
            bot.send_message(message.chat.id, f"🎁 Sizning PUBG akkauntingiz:\n{acc}")
        else:
            bot.send_message(message.chat.id, "❌ Kechirasiz, akkauntlar tugagan.")
    elif message.text == "➕ PUBG akkaunt qo‘shish" and message.from_user.id == ADMIN_ID:
        bot.send_message(message.chat.id, "🔧 Quyidagicha yuboring:\n\nusername:parol")
    elif ":" in message.text and message.from_user.id == ADMIN_ID:
        add_pubg_account(message.text)
        bot.send_message(message.chat.id, "✅ PUBG akkaunt qo‘shildi.")
    elif message.text == "📄 Qolganlar" and message.from_user.id == ADMIN_ID:
        if os.path.exists(ACCOUNTS_FILE):
            with open(ACCOUNTS_FILE, "r") as f:
                count = len(f.readlines())
            bot.send_message(message.chat.id, f"📊 Qolgan PUBG akkauntlar: {count} ta")
        else:
            bot.send_message(message.chat.id, "❌ Fayl topilmadi.")

bot.polling(non_stop=True)
